void line_fast(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t color);
